
0.0.7 / 2015-07-21
==================

  * component: update "dom" to v1.0.8
  * docs: add note about optional ms for `hide()`

0.0.6 / 2015-03-11
==================

  * re-add the `package.json` file
  * component: update "dom" to v1.0.7
  * component: update "emitter" to v1.2.0
  * component: update "description"
  * component: Pin deps (#10)
  * More readable HTML entity for the close button

0.0.4 / 2014-03-17
==================

  * Use escaped "×"
  * switching over to component/dom (as per @ianstormtaylor's comment)
  * remove jquery dependency
  * add test command to Makefile
  * Update emitter to 1.0.1
  * add .license property to component.json
  * add private .classname option

0.0.3 / 2012-08-30
==================

  * add "close" event
  * add `.Notification` export
